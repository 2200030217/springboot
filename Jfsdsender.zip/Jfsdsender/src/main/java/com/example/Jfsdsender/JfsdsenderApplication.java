package com.example.Jfsdsender;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JfsdsenderApplication {

	public static void main(String[] args) {
		SpringApplication.run(JfsdsenderApplication.class, args);
	}

}
