package com.example.Jfsdsender;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JfsdsenderApplicationTests {

	@Test
	void contextLoads() {
	}

}
