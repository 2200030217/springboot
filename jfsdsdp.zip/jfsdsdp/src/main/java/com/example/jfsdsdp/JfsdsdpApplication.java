package com.example.jfsdsdp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JfsdsdpApplication {

	public static void main(String[] args) {
		SpringApplication.run(JfsdsdpApplication.class, args);
	}

}
