package com.example.jfsdsdp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JfsdsdpApplicationTests {

	@Test
	void contextLoads() {
	}

}
